export type SocialIcon = Record<string, string | any>
